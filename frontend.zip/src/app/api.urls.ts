export const apiUrls={
    authServiceApi:'http://localhost:8000/api/auth/'
}